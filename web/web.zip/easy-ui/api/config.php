<?php
    global $config;
    $config["mysql"]["server"]="127.0.0.1";
    $config["mysql"]["user"]="root";
    $config["mysql"]["passwd"]="yangweihao20060531";
    $config["mysql"]["database"]="judge";
?>